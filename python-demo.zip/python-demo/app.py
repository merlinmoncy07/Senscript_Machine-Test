import os

from flask import Flask, render_template, request, send_from_directory
from pymongo import MongoClient

app = Flask(__name__)
UPLOAD_FOLDER = 'static/image/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Database configuration
USER = 'admin'
PASSWORD = 'yourpassword'
CLUSTER_NAME = 'cluster0'
DB_NAME = 'merlin'
COLLECTION_NAME = 'register'
MONGO_URI = f"mongodb+srv://{USER}:{PASSWORD}@{CLUSTER_NAME}.hbxor4w.mongodb.net/{DB_NAME}?retryWrites=true&w=majority"

client = MongoClient(MONGO_URI)
db = client[DB_NAME]
collection = db[COLLECTION_NAME]

# Serve static images
STATIC_FOLDER = os.path.join(os.path.dirname(
    os.path.abspath(__file__)), 'static')


@app.route('/static/images/<filename>')
def serve_image(filename):
    return send_from_directory(os.path.join(STATIC_FOLDER, 'image'), filename)

# Home page


@app.route('/')
def hello():
    return render_template("index.html")

# View all records


@app.route('/record_list')
def show_record_page():
    data = collection.find({})
    return render_template("view.html", data=data)

# Process form submission


@app.route('/process_form', methods=['POST'])
def process_form():
    if 'photo' not in request.files:
        return "No image uploaded"

    image = request.files['photo']
    if image.filename == '':
        return "No selected image"

    if image:
        filename = os.path.join(app.config['UPLOAD_FOLDER'], image.filename)
        image.save(filename)

        student_data = {
            'student_id': request.form.get('student_id'),
            'branch': request.form.get('branch'),
            'name': request.form.get('name'),
            'mobile': request.form.get('mobile'),
            'email': request.form.get('email'),
            'address': request.form.get('address'),
            'photo': image.filename
        }
        result = collection.insert_one(student_data)
        return f"Registration successful! Register ID = {result.inserted_id}"
    else:
        return "Image upload failed!"


if __name__ == '__main__':
    app.run()
