only created student registration reocrd and student view
database used mongo db atlas
